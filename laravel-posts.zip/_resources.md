# TailwindCSS
https://tailwindcss.com/
https://tailwindcss.com/docs/guides/laravel


https://tailwindcss.com/docs/padding


# daisyui
https://daisyui.com/docs/install/