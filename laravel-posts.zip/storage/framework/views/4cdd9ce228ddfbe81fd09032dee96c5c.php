

<?php $__env->startSection('content'); ?>

<div class="card card-compact w-96 bg-base-100 shadow-xl">
  <figure><img src="<?php echo e($post->thumbnail); ?>" alt="Shoes" /></figure>
  <div class="card-body">
    <h2 class="card-title"><?php echo e($post->title); ?></h2>
    <p><?php echo e($post->body); ?></p>
    <div class="card-actions justify-end">
      <button class="btn btn-primary">Buy Now</button>
    </div>
  </div>
  <div class="card-footer">
    <p>BY: <?php echo e($post->user_name); ?></p>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravel-posts\resources\views/posts/show.blade.php ENDPATH**/ ?>