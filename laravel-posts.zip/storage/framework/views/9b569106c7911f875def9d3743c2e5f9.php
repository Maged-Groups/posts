

<?php $__env->startSection('content'); ?>
<div class="overflow-x-auto">
  <table class="table">
    <!-- head -->
    <thead>
      <tr>
        <th>Thumbnail</th>
        <th>Title</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      
     <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
     <tr>
         <td>
         <div class="mask mask-squircle w-12 h-12">
                <img src="<?php echo e($post->thumbnail); ?>" alt="<?php echo e($post->title); ?>" />
              </div>
         </td>
        <td><?php echo e($post->title); ?></td>
        <td>
            <div>
                <a href='<?php echo e(route("posts.show", $post->id)); ?>' class='btn btn-neutral'>
                    <i class="fa fa-eye"></i>
                </a>
                <span class='btn btn-primary'>
                    <i class="fa fa-pencil"></i>
                </span>
                <span class='btn btn-secondary'>
                    <i class="fa fa-trash"></i>
                </span>
            </div>
        </td>
      </tr>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
  </table>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\RS-1855\posts\resources\views/posts/index.blade.php ENDPATH**/ ?>