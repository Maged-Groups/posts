<?php $__env->startSection('content'); ?>
<div class="max-w-md m-auto">


    <h2 class="text-2xl font-extrabold text-center mb-3 ">Create Your Post</h2>

    <form method="post" enctype="multipart/form-data" action="<?php echo e(route('posts.store')); ?>" class="flex flex-col gap-3">
        <label class="input input-bordered flex items-center gap-2">
            <i class="fa fa-pencil"></i>
            <input name='title' type="text" class="grow" placeholder="title" value="<?php echo e(@old('title')); ?>" />
        </label>
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <label class="flex gap-2 border p-2">
            <i class="fa fa-pencil"></i>
            <textarea name='body' class="w-full" placeholder="body">
                <?php echo e(@old('body')); ?>

            </textarea>
        </label>

        <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-red-600"><?php echo e($message); ?></p>
         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


        <label class="input input-bordered flex items-center gap-2">
            <i class="fa fa-pencil"></i>

            <select name='post_type_id' class="select select-primary w-full max-w-xs">
                <option>Select Post Type</option>

                <?php $__currentLoopData = $post_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option   <?php if(@old('post_type_id') == $post_type->id ): ?> selected  <?php endif; ?>   value="<?php echo e($post_type->id); ?>"><?php echo e($post_type->type); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </select>
        </label>

        <?php $__errorArgs = ['post_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="text-red-600"><?php echo e($message); ?></p>
         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <label class="input input-bordered flex items-center gap-2">
            <i class="fa fa-pencil"></i>

            <input name='thumbnail' type="file" class="file-input file-input-bordered file-input-secondary w-full max-w-xs" />

        </label>

        <?php $__errorArgs = ['thumbnail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-red-600"><?php echo e($message); ?></p>
         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <?php echo csrf_field(); ?>

        <input type="hidden"  name='_token' value="<?php echo e(csrf_token()); ?>">

        <button class="btn btn-primary">Create</button>



        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p class="alert bg-red-300 text-red-900"><?php echo e($error); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravel-posts\resources\views/posts/create.blade.php ENDPATH**/ ?>